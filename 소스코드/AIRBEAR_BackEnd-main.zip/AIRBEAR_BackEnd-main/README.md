# 삼성 낫 한성 (SAMSUNG NOT HANSUNG)

# AIRBEAR

AIRBEAR는 승무원 지망생들이 면접을 준비할 수 있도록 돕는 면접 도움 웹사이트입니다.  
AIRBEAR와 함께 쉽고 빠르게 승무원의 꿈을 이루세요!🐻‍❄️

![KakaoTalk_20240530_232005778](https://github.com/Airbear-HS/AIRBEAR_BackEnd/assets/143497860/dd6118cd-5e19-49b6-a0f1-33b181906028)

#Home화면

언제 어디서나 손쉽게 가입하고 플랫폼에 접속할 수 있습니다.
모바일 친화적인 웹사이트를 통해 이동 중에도 면접 스킬을 연습하세요.🏃‍♂️

![KakaoTalk_20240530_232005778_01](https://github.com/Airbear-HS/AIRBEAR_BackEnd/assets/143497860/247c9cfe-789c-4c45-8b47-21c7deb00a04)


#My Page에서 개인 맞춤형 학습

'오늘 할 일' 체크리스트를 활용하여 녹음된 자신의 답변을 체계적으로 재검토하고 개선할 부분을 찾아보세요. 
모범 답변과 상세 피드백을 통해 면접 기술을 더욱 향상시킬 수 있습니다.

![KakaoTalk_20240530_232005778_16](https://github.com/Airbear-HS/AIRBEAR_BackEnd/assets/143497860/5afc7089-147c-4967-b25a-a18b312a9dbb)
![KakaoTalk_20240530_232005778_17](https://github.com/Airbear-HS/AIRBEAR_BackEnd/assets/143497860/25f1696d-8e40-4f2b-a6be-2ad6e0644c9b)

#실전 면접 질문🤔

주요 항공사에서 실제로 사용하는 면접 질문을 연습하세요.
함께 제공되는 모범 답변을 통해 자신의 약점을 보완하고 강점을 극대화할 수 있습니다.
![KakaoTalk_20240530_232005778_10](https://github.com/Airbear-HS/AIRBEAR_BackEnd/assets/143497860/5a926c30-d24f-414b-bdf4-e1c9df411693)


![KakaoTalk_20240530_232005778_11](https://github.com/Airbear-HS/AIRBEAR_BackEnd/assets/143497860/a31818d3-be2b-47aa-b0eb-ee92b93cf745)

![KakaoTalk_20240530_232005778_12](https://github.com/Airbear-HS/AIRBEAR_BackEnd/assets/143497860/df6d1b4b-c218-43e1-973f-aafe7733af15)

#커뮤니티🤝

동료 취준생들과 피드백을 주고받으며 함께 성장하세요.
녹음된 나의 답변을 들려주고 의견을 들을 수 있어요.
![KakaoTalk_20240530_232005778_07](https://github.com/Airbear-HS/AIRBEAR_BackEnd/assets/143497860/eacff990-3647-4e75-9001-4f18c76f7e21)







